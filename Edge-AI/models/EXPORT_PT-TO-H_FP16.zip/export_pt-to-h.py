from ultralytics import YOLO
import torch
import io
import zlib
import sys

if len(sys.argv) != 3:
    print("Uso: python export_pt_to_h_yolo.py model.pt model.h")
    sys.exit(1)

input_pt = sys.argv[1]
output_h = sys.argv[2]

print(f"[INFO] Convertendo {input_pt} para {output_h}...")

# 1️⃣ Carrega o modelo YOLO
model = YOLO(input_pt)

# 2️⃣ Pega apenas os tensores do state_dict
state_dict = model.model.state_dict()

# 3️⃣ Converte para FP16
for k in state_dict:
    state_dict[k] = state_dict[k].half()

# 4️⃣ Serializa e comprime
buffer = io.BytesIO()
torch.save(state_dict, buffer)
data = buffer.getvalue()
compressed = zlib.compress(data, level=9)

print(f"[INFO] Tamanho original: {len(data)/1024:.2f} KB, comprimido: {len(compressed)/1024:.2f} KB")

# 5️⃣ Gera .h
with open(output_h, "w") as f:
    f.write("#ifndef MODEL_H\n#define MODEL_H\n\n")
    f.write("const unsigned char model_data[] = {")
    f.write(",".join(str(b) for b in compressed))
    f.write("};\n")
    f.write(f"const unsigned int model_data_len = {len(compressed)};\n\n")
    f.write("#endif // MODEL_H\n")

print(f"[✔] Arquivo {output_h} gerado com sucesso!")
